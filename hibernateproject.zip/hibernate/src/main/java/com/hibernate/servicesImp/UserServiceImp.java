package com.hibernate.servicesImp;

import java.io.Serializable;
import java.util.List;

import com.hibernate.dao.UserDao;
import com.hibernate.entity.user;
import com.hibernate.services.UserService;

public class UserServiceImp  implements UserService ,Serializable{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private UserDao userdao;
		@Override
		public user findById(Integer id) {
			// TODO Auto-generated method stub
			return userdao.findById(id);
		}
		@Override
		public user findByusername(String username) {
			// TODO Auto-generated method stub
			return userdao.findByUsername(username);
		}
		@Override
		public Object save(user entity) {
			// TODO Auto-generated method stub
			return userdao.save(entity);
		}
		@Override
		public void update(user entity) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void delete(user entity) {
			// TODO Auto-generated method stub
			userdao.delete(entity);
		}
		@Override
		public List<user> findAll() {
			// TODO Auto-generated method stub
			return userdao.findAll();
		}
		

}
