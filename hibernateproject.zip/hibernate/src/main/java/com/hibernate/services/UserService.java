package com.hibernate.services;


import com.hibernate.entity.user;

public interface UserService  extends AbstractService<user> {

public user findById(Integer id);
	
public user findByusername(String username) ;



	
}
