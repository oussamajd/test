package com.hibernate.services;

import java.util.List;



	public interface AbstractService<T> {

	 
		public Object save(T entity);

	    public void update(T entity);

	    public List<T> findAll();

		public void delete(T entity);    

	 
	 
}
