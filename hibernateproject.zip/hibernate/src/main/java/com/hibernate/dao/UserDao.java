
package com.hibernate.dao;

import com.hibernate.entity.user;

public interface UserDao extends AbstractDao<user> {
		
		 public user findById(Integer id);
		 
		 public user findByUsername(String Username);
			    

		 


}
