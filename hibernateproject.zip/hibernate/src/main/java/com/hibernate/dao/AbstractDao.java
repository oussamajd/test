package com.hibernate.dao;

import java.util.List;

public interface AbstractDao<T> {
		
		 public Object save(T entity);
		
		 public void update(T entity);


		 public List<T> findAll();

		 public T find(Object idClass);

		void delete(T entity);


	}

