package com.hibernate.doaImp;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import com.hibernate.dao.*;



public class AbstractDAOImpl<T> extends HibernateDaoSupport implements AbstractDao<T>,Serializable{

	/**
 * 
 */
private static final long serialVersionUID = 1L;
	private Class<T> entityClass;

	public AbstractDAOImpl(Class<T> entityClass) {
		this.entityClass = entityClass;
}

	@Override
	public Object save(T entity) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(entity);
		return null;
	}

	@Override
	public void update(T entity) {
		// TODO Auto-generated method stub
		getHibernateTemplate().update(entity);
		
	}

	@Override
	public void delete(T entity) {
		
	 getHibernateTemplate().delete(entity);

	}

	@Override
	public List<T> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T find(Object idClass) {
		// TODO Auto-generated method stub
		return null;
	}



}