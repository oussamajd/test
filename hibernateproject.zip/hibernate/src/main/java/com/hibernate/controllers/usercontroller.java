package com.hibernate.controllers;





public class usercontroller  {


	
}
