package com.hibernate;



import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hibernate.entity.user;
import com.hibernate.util.HibernateUtil;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	try {
    		user user =new  user();
    		System.out.println("user created");
    		user.setNom("jedidi");
    		user.setPrenom("oussema");
    		
    		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
    		System.out.println("SessionFactory created ");
    		
    		Session session = sessionFactory.openSession();
    		System.out.println("session opened");
    		session.beginTransaction();
    		session.save(user);
    		System.out.println("inserted successfully");
    		session.beginTransaction().commit();
    		session.close();
    		sessionFactory.close();
			
		} catch (Exception e) {
			System.err.println(e);
			// TODO: handle exception
		}
	
    	
    }
}
